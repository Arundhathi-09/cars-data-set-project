```python
import pandas as pd
import numpy as np
import seaborn as sns #visualisation
import matplotlib.pyplot as plt #visualisation
%matplotlib inline 
sns.set(color_codes=True)
from scipy import stats
import warnings
warnings.filterwarnings("ignore")
```

# LOADING DATASET


```python
pd.read_csv(r"C:\Users\arund\Downloads\Cars_data.csv")
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Make</th>
      <th>Model</th>
      <th>Year</th>
      <th>Engine Fuel Type</th>
      <th>Engine HP</th>
      <th>Engine Cylinders</th>
      <th>Transmission Type</th>
      <th>Driven_Wheels</th>
      <th>Number of Doors</th>
      <th>Market Category</th>
      <th>Vehicle Size</th>
      <th>Vehicle Style</th>
      <th>highway MPG</th>
      <th>city mpg</th>
      <th>Popularity</th>
      <th>MSRP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW</td>
      <td>1 Series M</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>335.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Factory Tuner,Luxury,High-Performance</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>26</td>
      <td>19</td>
      <td>3916</td>
      <td>46135</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Luxury,Performance</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>19</td>
      <td>3916</td>
      <td>40650</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Luxury,High-Performance</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>20</td>
      <td>3916</td>
      <td>36350</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Luxury,Performance</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>29450</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Luxury</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>34500</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>11909</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Crossover,Hatchback,Luxury</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>46120</td>
    </tr>
    <tr>
      <th>11910</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Crossover,Hatchback,Luxury</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>56670</td>
    </tr>
    <tr>
      <th>11911</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Crossover,Hatchback,Luxury</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>50620</td>
    </tr>
    <tr>
      <th>11912</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2013</td>
      <td>premium unleaded (recommended)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Crossover,Hatchback,Luxury</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>50920</td>
    </tr>
    <tr>
      <th>11913</th>
      <td>Lincoln</td>
      <td>Zephyr</td>
      <td>2006</td>
      <td>regular unleaded</td>
      <td>221.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>front wheel drive</td>
      <td>4.0</td>
      <td>Luxury</td>
      <td>Midsize</td>
      <td>Sedan</td>
      <td>26</td>
      <td>17</td>
      <td>61</td>
      <td>28995</td>
    </tr>
  </tbody>
</table>
<p>11914 rows × 16 columns</p>
</div>




```python
df = pd.read_csv(r"C:\Users\arund\Downloads\Cars_data.csv")
```

# NO.of Rows and Columns


```python
df.shape
```




    (11914, 16)



# Listing The First 5 Rows


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Make</th>
      <th>Model</th>
      <th>Year</th>
      <th>Engine Fuel Type</th>
      <th>Engine HP</th>
      <th>Engine Cylinders</th>
      <th>Transmission Type</th>
      <th>Driven_Wheels</th>
      <th>Number of Doors</th>
      <th>Market Category</th>
      <th>Vehicle Size</th>
      <th>Vehicle Style</th>
      <th>highway MPG</th>
      <th>city mpg</th>
      <th>Popularity</th>
      <th>MSRP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW</td>
      <td>1 Series M</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>335.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Factory Tuner,Luxury,High-Performance</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>26</td>
      <td>19</td>
      <td>3916</td>
      <td>46135</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Luxury,Performance</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>19</td>
      <td>3916</td>
      <td>40650</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Luxury,High-Performance</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>20</td>
      <td>3916</td>
      <td>36350</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Luxury,Performance</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>29450</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Luxury</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>34500</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Make</th>
      <th>Model</th>
      <th>Year</th>
      <th>Engine Fuel Type</th>
      <th>Engine HP</th>
      <th>Engine Cylinders</th>
      <th>Transmission Type</th>
      <th>Driven_Wheels</th>
      <th>Number of Doors</th>
      <th>Market Category</th>
      <th>Vehicle Size</th>
      <th>Vehicle Style</th>
      <th>highway MPG</th>
      <th>city mpg</th>
      <th>Popularity</th>
      <th>MSRP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>11909</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Crossover,Hatchback,Luxury</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>46120</td>
    </tr>
    <tr>
      <th>11910</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Crossover,Hatchback,Luxury</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>56670</td>
    </tr>
    <tr>
      <th>11911</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Crossover,Hatchback,Luxury</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>50620</td>
    </tr>
    <tr>
      <th>11912</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2013</td>
      <td>premium unleaded (recommended)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Crossover,Hatchback,Luxury</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>50920</td>
    </tr>
    <tr>
      <th>11913</th>
      <td>Lincoln</td>
      <td>Zephyr</td>
      <td>2006</td>
      <td>regular unleaded</td>
      <td>221.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>front wheel drive</td>
      <td>4.0</td>
      <td>Luxury</td>
      <td>Midsize</td>
      <td>Sedan</td>
      <td>26</td>
      <td>17</td>
      <td>61</td>
      <td>28995</td>
    </tr>
  </tbody>
</table>
</div>



# checking the Datatypes 


```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 11914 entries, 0 to 11913
    Data columns (total 16 columns):
     #   Column             Non-Null Count  Dtype  
    ---  ------             --------------  -----  
     0   Make               11914 non-null  object 
     1   Model              11914 non-null  object 
     2   Year               11914 non-null  int64  
     3   Engine Fuel Type   11911 non-null  object 
     4   Engine HP          11845 non-null  float64
     5   Engine Cylinders   11884 non-null  float64
     6   Transmission Type  11914 non-null  object 
     7   Driven_Wheels      11914 non-null  object 
     8   Number of Doors    11908 non-null  float64
     9   Market Category    8172 non-null   object 
     10  Vehicle Size       11914 non-null  object 
     11  Vehicle Style      11914 non-null  object 
     12  highway MPG        11914 non-null  int64  
     13  city mpg           11914 non-null  int64  
     14  Popularity         11914 non-null  int64  
     15  MSRP               11914 non-null  int64  
    dtypes: float64(3), int64(5), object(8)
    memory usage: 1.5+ MB
    

# Dropping Irrevalent Columns


```python
df.drop('Market Category',axis = 1,inplace = True)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Make</th>
      <th>Model</th>
      <th>Year</th>
      <th>Engine Fuel Type</th>
      <th>Engine HP</th>
      <th>Engine Cylinders</th>
      <th>Transmission Type</th>
      <th>Driven_Wheels</th>
      <th>Number of Doors</th>
      <th>Vehicle Size</th>
      <th>Vehicle Style</th>
      <th>highway MPG</th>
      <th>city mpg</th>
      <th>Popularity</th>
      <th>MSRP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW</td>
      <td>1 Series M</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>335.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>26</td>
      <td>19</td>
      <td>3916</td>
      <td>46135</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>19</td>
      <td>3916</td>
      <td>40650</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>20</td>
      <td>3916</td>
      <td>36350</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>29450</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>34500</td>
    </tr>
  </tbody>
</table>
</div>



# Renaming The Columns


```python
df.rename(columns = {'Make':'Brand','highway MPG':'Highway km/L', 'city mpg':'city km/L', },inplace = True)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brand</th>
      <th>Model</th>
      <th>Year</th>
      <th>Engine Fuel Type</th>
      <th>Engine HP</th>
      <th>Engine Cylinders</th>
      <th>Transmission Type</th>
      <th>Driven_Wheels</th>
      <th>Number of Doors</th>
      <th>Vehicle Size</th>
      <th>Vehicle Style</th>
      <th>Highway km/L</th>
      <th>city km/L</th>
      <th>Popularity</th>
      <th>MSRP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW</td>
      <td>1 Series M</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>335.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>26</td>
      <td>19</td>
      <td>3916</td>
      <td>46135</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>19</td>
      <td>3916</td>
      <td>40650</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>20</td>
      <td>3916</td>
      <td>36350</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>29450</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>34500</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.duplicated().sum()
```




    720




```python
df.isnull().sum()
```




    Brand                 0
    Model                 0
    Year                  0
    Engine Fuel Type      3
    Engine HP            69
    Engine Cylinders     30
    Transmission Type     0
    Driven_Wheels         0
    Number of Doors       6
    Vehicle Size          0
    Vehicle Style         0
    Highway km/L          0
    city km/L             0
    Popularity            0
    MSRP                  0
    dtype: int64




```python
df.isnull().any()
```




    Brand                False
    Model                False
    Year                 False
    Engine Fuel Type      True
    Engine HP             True
    Engine Cylinders      True
    Transmission Type    False
    Driven_Wheels        False
    Number of Doors       True
    Vehicle Size         False
    Vehicle Style        False
    Highway km/L         False
    city km/L            False
    Popularity           False
    MSRP                 False
    dtype: bool




```python
df.dropna()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brand</th>
      <th>Model</th>
      <th>Year</th>
      <th>Engine Fuel Type</th>
      <th>Engine HP</th>
      <th>Engine Cylinders</th>
      <th>Transmission Type</th>
      <th>Driven_Wheels</th>
      <th>Number of Doors</th>
      <th>Vehicle Size</th>
      <th>Vehicle Style</th>
      <th>Highway km/L</th>
      <th>city km/L</th>
      <th>Popularity</th>
      <th>MSRP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW</td>
      <td>1 Series M</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>335.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>26</td>
      <td>19</td>
      <td>3916</td>
      <td>46135</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>19</td>
      <td>3916</td>
      <td>40650</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>20</td>
      <td>3916</td>
      <td>36350</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>29450</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>34500</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>11909</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>46120</td>
    </tr>
    <tr>
      <th>11910</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>56670</td>
    </tr>
    <tr>
      <th>11911</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>50620</td>
    </tr>
    <tr>
      <th>11912</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2013</td>
      <td>premium unleaded (recommended)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>50920</td>
    </tr>
    <tr>
      <th>11913</th>
      <td>Lincoln</td>
      <td>Zephyr</td>
      <td>2006</td>
      <td>regular unleaded</td>
      <td>221.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>front wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>Sedan</td>
      <td>26</td>
      <td>17</td>
      <td>61</td>
      <td>28995</td>
    </tr>
  </tbody>
</table>
<p>11812 rows × 15 columns</p>
</div>




```python
df.fillna(0, inplace=True)
```


```python
df.isnull().sum()
```




    Brand                0
    Model                0
    Year                 0
    Engine Fuel Type     0
    Engine HP            0
    Engine Cylinders     0
    Transmission Type    0
    Driven_Wheels        0
    Number of Doors      0
    Vehicle Size         0
    Vehicle Style        0
    Highway km/L         0
    city km/L            0
    Popularity           0
    MSRP                 0
    dtype: int64




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Engine HP</th>
      <th>Engine Cylinders</th>
      <th>Number of Doors</th>
      <th>Highway km/L</th>
      <th>city km/L</th>
      <th>Popularity</th>
      <th>MSRP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>11914.000000</td>
      <td>11914.000000</td>
      <td>11914.000000</td>
      <td>11914.000000</td>
      <td>11914.000000</td>
      <td>11914.000000</td>
      <td>11914.000000</td>
      <td>1.191400e+04</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2010.384338</td>
      <td>247.941749</td>
      <td>5.614655</td>
      <td>3.434363</td>
      <td>26.637485</td>
      <td>19.733255</td>
      <td>1554.911197</td>
      <td>4.059474e+04</td>
    </tr>
    <tr>
      <th>std</th>
      <td>7.579740</td>
      <td>110.507669</td>
      <td>1.800554</td>
      <td>0.884460</td>
      <td>8.863001</td>
      <td>8.987798</td>
      <td>1441.855347</td>
      <td>6.010910e+04</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1990.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>12.000000</td>
      <td>7.000000</td>
      <td>2.000000</td>
      <td>2.000000e+03</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2007.000000</td>
      <td>170.000000</td>
      <td>4.000000</td>
      <td>2.000000</td>
      <td>22.000000</td>
      <td>16.000000</td>
      <td>549.000000</td>
      <td>2.100000e+04</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2015.000000</td>
      <td>225.000000</td>
      <td>6.000000</td>
      <td>4.000000</td>
      <td>26.000000</td>
      <td>18.000000</td>
      <td>1385.000000</td>
      <td>2.999500e+04</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2016.000000</td>
      <td>300.000000</td>
      <td>6.000000</td>
      <td>4.000000</td>
      <td>30.000000</td>
      <td>22.000000</td>
      <td>2009.000000</td>
      <td>4.223125e+04</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2017.000000</td>
      <td>1001.000000</td>
      <td>16.000000</td>
      <td>4.000000</td>
      <td>354.000000</td>
      <td>137.000000</td>
      <td>5657.000000</td>
      <td>2.065902e+06</td>
    </tr>
  </tbody>
</table>
</div>




```python
plt.bar(df["Highway km/L"], df["city km/L"])
plt.show()

```


    
![png](output_24_0.png)
    



```python
sns.distplot(df['Year'])
```




    <Axes: xlabel='Year', ylabel='Density'>




    
![png](output_25_1.png)
    



```python
sns.distplot(df['city km/L'])
```




    <Axes: xlabel='city km/L', ylabel='Density'>




    
![png](output_26_1.png)
    



```python
sns.distplot(df['Highway km/L'])
```




    <Axes: xlabel='Highway km/L', ylabel='Density'>




    
![png](output_27_1.png)
    


# Basic Statistics


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year</th>
      <th>Engine HP</th>
      <th>Engine Cylinders</th>
      <th>Number of Doors</th>
      <th>Highway km/L</th>
      <th>city km/L</th>
      <th>Popularity</th>
      <th>MSRP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>11914.000000</td>
      <td>11914.000000</td>
      <td>11914.000000</td>
      <td>11914.000000</td>
      <td>11914.000000</td>
      <td>11914.000000</td>
      <td>11914.000000</td>
      <td>1.191400e+04</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2010.384338</td>
      <td>247.941749</td>
      <td>5.614655</td>
      <td>3.434363</td>
      <td>26.637485</td>
      <td>19.733255</td>
      <td>1554.911197</td>
      <td>4.059474e+04</td>
    </tr>
    <tr>
      <th>std</th>
      <td>7.579740</td>
      <td>110.507669</td>
      <td>1.800554</td>
      <td>0.884460</td>
      <td>8.863001</td>
      <td>8.987798</td>
      <td>1441.855347</td>
      <td>6.010910e+04</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1990.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>12.000000</td>
      <td>7.000000</td>
      <td>2.000000</td>
      <td>2.000000e+03</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2007.000000</td>
      <td>170.000000</td>
      <td>4.000000</td>
      <td>2.000000</td>
      <td>22.000000</td>
      <td>16.000000</td>
      <td>549.000000</td>
      <td>2.100000e+04</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2015.000000</td>
      <td>225.000000</td>
      <td>6.000000</td>
      <td>4.000000</td>
      <td>26.000000</td>
      <td>18.000000</td>
      <td>1385.000000</td>
      <td>2.999500e+04</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2016.000000</td>
      <td>300.000000</td>
      <td>6.000000</td>
      <td>4.000000</td>
      <td>30.000000</td>
      <td>22.000000</td>
      <td>2009.000000</td>
      <td>4.223125e+04</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2017.000000</td>
      <td>1001.000000</td>
      <td>16.000000</td>
      <td>4.000000</td>
      <td>354.000000</td>
      <td>137.000000</td>
      <td>5657.000000</td>
      <td>2.065902e+06</td>
    </tr>
  </tbody>
</table>
</div>




```python
columns = list(df)
```


```python
columns
```




    ['Brand',
     'Model',
     'Year',
     'Engine Fuel Type',
     'Engine HP',
     'Engine Cylinders',
     'Transmission Type',
     'Driven_Wheels',
     'Number of Doors',
     'Vehicle Size',
     'Vehicle Style',
     'Highway km/L',
     'city km/L',
     'Popularity',
     'MSRP']



# Checking Null Values


```python
df.isnull().sum()
```




    Brand                0
    Model                0
    Year                 0
    Engine Fuel Type     0
    Engine HP            0
    Engine Cylinders     0
    Transmission Type    0
    Driven_Wheels        0
    Number of Doors      0
    Vehicle Size         0
    Vehicle Style        0
    Highway km/L         0
    city km/L            0
    Popularity           0
    MSRP                 0
    dtype: int64



# Calculating Total Zeros in Given Data


```python
(df[columns[3:6]] == 0).sum()
```




    Engine Fuel Type     3
    Engine HP           69
    Engine Cylinders    86
    dtype: int64



# Replace Statement


```python
df[columns[3:6]] = df[columns[3:6]].replace(0,np.nan)
```


```python
df.isnull().sum()
```




    Brand                 0
    Model                 0
    Year                  0
    Engine Fuel Type      3
    Engine HP            69
    Engine Cylinders     86
    Transmission Type     0
    Driven_Wheels         0
    Number of Doors       0
    Vehicle Size          0
    Vehicle Style         0
    Highway km/L          0
    city km/L             0
    Popularity            0
    MSRP                  0
    dtype: int64




```python
df.shape
```




    (11914, 15)



# Drop Empty Rows


```python
df.dropna(inplace = True)
```


```python
df.shape
```




    (11800, 15)




```python
df.isnull().sum()
```




    Brand                0
    Model                0
    Year                 0
    Engine Fuel Type     0
    Engine HP            0
    Engine Cylinders     0
    Transmission Type    0
    Driven_Wheels        0
    Number of Doors      0
    Vehicle Size         0
    Vehicle Style        0
    Highway km/L         0
    city km/L            0
    Popularity           0
    MSRP                 0
    dtype: int64




```python
sns.distplot(df['Engine HP'])
```




    <Axes: xlabel='Engine HP', ylabel='Density'>




    
![png](output_44_1.png)
    



```python
sns.distplot(df['Year'])
```




    <Axes: xlabel='Year', ylabel='Density'>




    
![png](output_45_1.png)
    



```python
sns.distplot(df['Highway km/L'])
```




    <Axes: xlabel='Highway km/L', ylabel='Density'>




    
![png](output_46_1.png)
    


# Fillna Method Using Mean


```python
col = df['Number of Doors']
```


```python
col = col.fillna(col.mean(),inplace = True)
```


```python
df.isnull().sum()
```




    Brand                0
    Model                0
    Year                 0
    Engine Fuel Type     0
    Engine HP            0
    Engine Cylinders     0
    Transmission Type    0
    Driven_Wheels        0
    Number of Doors      0
    Vehicle Size         0
    Vehicle Style        0
    Highway km/L         0
    city km/L            0
    Popularity           0
    MSRP                 0
    dtype: int64




```python
df[df.duplicated()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brand</th>
      <th>Model</th>
      <th>Year</th>
      <th>Engine Fuel Type</th>
      <th>Engine HP</th>
      <th>Engine Cylinders</th>
      <th>Transmission Type</th>
      <th>Driven_Wheels</th>
      <th>Number of Doors</th>
      <th>Vehicle Size</th>
      <th>Vehicle Style</th>
      <th>Highway km/L</th>
      <th>city km/L</th>
      <th>Popularity</th>
      <th>MSRP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>14</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2013</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>19</td>
      <td>3916</td>
      <td>31500</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Audi</td>
      <td>100</td>
      <td>1992</td>
      <td>regular unleaded</td>
      <td>172.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>front wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>Sedan</td>
      <td>24</td>
      <td>17</td>
      <td>3105</td>
      <td>2000</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Audi</td>
      <td>100</td>
      <td>1992</td>
      <td>regular unleaded</td>
      <td>172.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>front wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>Sedan</td>
      <td>24</td>
      <td>17</td>
      <td>3105</td>
      <td>2000</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Audi</td>
      <td>100</td>
      <td>1993</td>
      <td>regular unleaded</td>
      <td>172.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>front wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>Sedan</td>
      <td>24</td>
      <td>17</td>
      <td>3105</td>
      <td>2000</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Audi</td>
      <td>100</td>
      <td>1993</td>
      <td>regular unleaded</td>
      <td>172.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>front wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>Sedan</td>
      <td>24</td>
      <td>17</td>
      <td>3105</td>
      <td>2000</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>11481</th>
      <td>Suzuki</td>
      <td>X-90</td>
      <td>1998</td>
      <td>regular unleaded</td>
      <td>95.0</td>
      <td>4.0</td>
      <td>MANUAL</td>
      <td>four wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>2dr SUV</td>
      <td>26</td>
      <td>22</td>
      <td>481</td>
      <td>2000</td>
    </tr>
    <tr>
      <th>11603</th>
      <td>Volvo</td>
      <td>XC60</td>
      <td>2017</td>
      <td>regular unleaded</td>
      <td>302.0</td>
      <td>4.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr SUV</td>
      <td>29</td>
      <td>20</td>
      <td>870</td>
      <td>46350</td>
    </tr>
    <tr>
      <th>11604</th>
      <td>Volvo</td>
      <td>XC60</td>
      <td>2017</td>
      <td>regular unleaded</td>
      <td>240.0</td>
      <td>4.0</td>
      <td>AUTOMATIC</td>
      <td>front wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr SUV</td>
      <td>30</td>
      <td>23</td>
      <td>870</td>
      <td>40950</td>
    </tr>
    <tr>
      <th>11708</th>
      <td>Suzuki</td>
      <td>XL7</td>
      <td>2008</td>
      <td>regular unleaded</td>
      <td>252.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr SUV</td>
      <td>22</td>
      <td>15</td>
      <td>481</td>
      <td>29149</td>
    </tr>
    <tr>
      <th>11717</th>
      <td>Suzuki</td>
      <td>XL7</td>
      <td>2008</td>
      <td>regular unleaded</td>
      <td>252.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>front wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr SUV</td>
      <td>22</td>
      <td>16</td>
      <td>481</td>
      <td>27499</td>
    </tr>
  </tbody>
</table>
<p>720 rows × 15 columns</p>
</div>




```python
df[df.duplicated(['Brand','Model'])]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brand</th>
      <th>Model</th>
      <th>Year</th>
      <th>Engine Fuel Type</th>
      <th>Engine HP</th>
      <th>Engine Cylinders</th>
      <th>Transmission Type</th>
      <th>Driven_Wheels</th>
      <th>Number of Doors</th>
      <th>Vehicle Size</th>
      <th>Vehicle Style</th>
      <th>Highway km/L</th>
      <th>city km/L</th>
      <th>Popularity</th>
      <th>MSRP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>20</td>
      <td>3916</td>
      <td>36350</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>29450</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>34500</td>
    </tr>
    <tr>
      <th>5</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>31200</td>
    </tr>
    <tr>
      <th>6</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>26</td>
      <td>17</td>
      <td>3916</td>
      <td>44100</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>11908</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>50520</td>
    </tr>
    <tr>
      <th>11909</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>46120</td>
    </tr>
    <tr>
      <th>11910</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>56670</td>
    </tr>
    <tr>
      <th>11911</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>50620</td>
    </tr>
    <tr>
      <th>11912</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2013</td>
      <td>premium unleaded (recommended)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>50920</td>
    </tr>
  </tbody>
</table>
<p>10886 rows × 15 columns</p>
</div>




```python
df.drop_duplicates()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brand</th>
      <th>Model</th>
      <th>Year</th>
      <th>Engine Fuel Type</th>
      <th>Engine HP</th>
      <th>Engine Cylinders</th>
      <th>Transmission Type</th>
      <th>Driven_Wheels</th>
      <th>Number of Doors</th>
      <th>Vehicle Size</th>
      <th>Vehicle Style</th>
      <th>Highway km/L</th>
      <th>city km/L</th>
      <th>Popularity</th>
      <th>MSRP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW</td>
      <td>1 Series M</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>335.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>26</td>
      <td>19</td>
      <td>3916</td>
      <td>46135</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>19</td>
      <td>3916</td>
      <td>40650</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>20</td>
      <td>3916</td>
      <td>36350</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>29450</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>34500</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>11909</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>46120</td>
    </tr>
    <tr>
      <th>11910</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>56670</td>
    </tr>
    <tr>
      <th>11911</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2012</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>50620</td>
    </tr>
    <tr>
      <th>11912</th>
      <td>Acura</td>
      <td>ZDX</td>
      <td>2013</td>
      <td>premium unleaded (recommended)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>all wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>4dr Hatchback</td>
      <td>23</td>
      <td>16</td>
      <td>204</td>
      <td>50920</td>
    </tr>
    <tr>
      <th>11913</th>
      <td>Lincoln</td>
      <td>Zephyr</td>
      <td>2006</td>
      <td>regular unleaded</td>
      <td>221.0</td>
      <td>6.0</td>
      <td>AUTOMATIC</td>
      <td>front wheel drive</td>
      <td>4.0</td>
      <td>Midsize</td>
      <td>Sedan</td>
      <td>26</td>
      <td>17</td>
      <td>61</td>
      <td>28995</td>
    </tr>
  </tbody>
</table>
<p>11080 rows × 15 columns</p>
</div>




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Brand</th>
      <th>Model</th>
      <th>Year</th>
      <th>Engine Fuel Type</th>
      <th>Engine HP</th>
      <th>Engine Cylinders</th>
      <th>Transmission Type</th>
      <th>Driven_Wheels</th>
      <th>Number of Doors</th>
      <th>Vehicle Size</th>
      <th>Vehicle Style</th>
      <th>Highway km/L</th>
      <th>city km/L</th>
      <th>Popularity</th>
      <th>MSRP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BMW</td>
      <td>1 Series M</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>335.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>26</td>
      <td>19</td>
      <td>3916</td>
      <td>46135</td>
    </tr>
    <tr>
      <th>1</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>19</td>
      <td>3916</td>
      <td>40650</td>
    </tr>
    <tr>
      <th>2</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>300.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>20</td>
      <td>3916</td>
      <td>36350</td>
    </tr>
    <tr>
      <th>3</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Coupe</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>29450</td>
    </tr>
    <tr>
      <th>4</th>
      <td>BMW</td>
      <td>1 Series</td>
      <td>2011</td>
      <td>premium unleaded (required)</td>
      <td>230.0</td>
      <td>6.0</td>
      <td>MANUAL</td>
      <td>rear wheel drive</td>
      <td>2.0</td>
      <td>Compact</td>
      <td>Convertible</td>
      <td>28</td>
      <td>18</td>
      <td>3916</td>
      <td>34500</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.shape
```




    (11800, 15)




```python
df['Year'].unique()
```




    array([2011, 2012, 2013, 1992, 1993, 1994, 2017, 1991, 2016, 1990, 2015,
           1996, 1997, 1998, 2014, 1999, 2002, 2003, 2004, 1995, 2007, 2008,
           2009, 2001, 2010, 2000, 2005, 2006], dtype=int64)




```python
# Example: Count of entries per year
year_counts = df['Year'].value_counts().sort_index()

plt.figure(figsize=(10, 5))
plt.bar(year_counts.index, year_counts.values, color='skyblue')
plt.title("Number of Entries by Year")
plt.xlabel("Year")
plt.ylabel("Count")
plt.show()

```


    
![png](output_57_0.png)
    



```python
df['Brand'].unique()
```




    array(['BMW', 'Audi', 'FIAT', 'Mercedes-Benz', 'Chrysler', 'Nissan',
           'Volvo', 'Mazda', 'Mitsubishi', 'Ferrari', 'Alfa Romeo', 'Toyota',
           'McLaren', 'Maybach', 'Pontiac', 'Porsche', 'Saab', 'GMC',
           'Hyundai', 'Plymouth', 'Honda', 'Oldsmobile', 'Suzuki', 'Ford',
           'Cadillac', 'Kia', 'Bentley', 'Chevrolet', 'Dodge', 'Lamborghini',
           'Lincoln', 'Subaru', 'Volkswagen', 'Spyker', 'Buick', 'Acura',
           'Rolls-Royce', 'Maserati', 'Lexus', 'Aston Martin', 'Land Rover',
           'Lotus', 'Infiniti', 'Scion', 'Genesis', 'HUMMER', 'Bugatti'],
          dtype=object)




```python
df['Brand'].nunique()
```




    47




```python

category_counts = df['Brand'].value_counts()
plt.figure(figsize=(19, 16))
plt.pie(category_counts, labels=category_counts.index, autopct='%1.1f%%', startangle=140)
plt.title("Proportion of Each Category")
plt.show()

```


    
![png](output_60_0.png)
    



```python

brand_ratings = df.groupby('Brand')['MSRP'].mean().sort_values()

plt.figure(figsize=(20, 6))
sns.barplot(x=brand_ratings.index, y=brand_ratings.values, palette="viridis")
plt.title("Average Rating by Brand")
plt.xlabel("Brand", fontsize = 10)
plt.ylabel("MSRP")
plt.xticks(rotation=45)
plt.show()

```


    
![png](output_61_0.png)
    



```python
# Get top 10 brands by frequency
top_10_brands = df['Brand'].value_counts().head(10)
print(top_10_brands)

```

    Brand
    Chevrolet     1109
    Ford           868
    Volkswagen     805
    Toyota         743
    Dodge          626
    Nissan         548
    GMC            515
    Honda          447
    Mazda          403
    Cadillac       397
    Name: count, dtype: int64
    


```python
import matplotlib.pyplot as plt

# Plotting the top 10 brands
plt.figure(figsize=(10, 6))
top_10_brands.plot(kind='bar', color='skyblue')
plt.title("Top 10 Brands by Frequency")
plt.xlabel("Brand")
plt.ylabel("Count")
plt.xticks(rotation=45)
plt.show()

```


    
![png](output_63_0.png)
    



```python
import matplotlib.pyplot as plt

plt.figure(figsize=(10, 6))
plt.hist(df['MSRP'], bins=30, color='skyblue', edgecolor='black')
plt.title("Distribution of MSRP")
plt.xlabel("MSRP")
plt.ylabel("Brand")
plt.show()

```


    
![png](output_64_0.png)
    



```python
df['MSRP'].unique()
```




    array([46135, 40650, 36350, ..., 46120, 50620, 50920], dtype=int64)




```python
# Find the top 10 entries by MSRP
top_msrp = df.nlargest(10, 'MSRP')
print(top_msrp)

```

                 Brand        Model  Year             Engine Fuel Type  Engine HP  \
    11362      Bugatti  Veyron 16.4  2008  premium unleaded (required)     1001.0   
    11364      Bugatti  Veyron 16.4  2009  premium unleaded (required)     1001.0   
    8486   Lamborghini     Reventon  2008  premium unleaded (required)      650.0   
    11363      Bugatti  Veyron 16.4  2008  premium unleaded (required)     1001.0   
    6351       Maybach    Landaulet  2012  premium unleaded (required)      620.0   
    6350       Maybach    Landaulet  2011  premium unleaded (required)      620.0   
    4024       Ferrari         Enzo  2003  premium unleaded (required)      660.0   
    1622   Lamborghini    Aventador  2014  premium unleaded (required)      720.0   
    1626   Lamborghini    Aventador  2015  premium unleaded (required)      720.0   
    1629   Lamborghini    Aventador  2016  premium unleaded (required)      750.0   
    
           Engine Cylinders Transmission Type     Driven_Wheels  Number of Doors  \
    11362              16.0  AUTOMATED_MANUAL   all wheel drive              2.0   
    11364              16.0  AUTOMATED_MANUAL   all wheel drive              2.0   
    8486               12.0  AUTOMATED_MANUAL   all wheel drive              2.0   
    11363              16.0  AUTOMATED_MANUAL   all wheel drive              2.0   
    6351               12.0         AUTOMATIC  rear wheel drive              4.0   
    6350               12.0         AUTOMATIC  rear wheel drive              4.0   
    4024               12.0  AUTOMATED_MANUAL  rear wheel drive              2.0   
    1622               12.0  AUTOMATED_MANUAL   all wheel drive              2.0   
    1626               12.0  AUTOMATED_MANUAL   all wheel drive              2.0   
    1629               12.0  AUTOMATED_MANUAL   all wheel drive              2.0   
    
          Vehicle Size Vehicle Style  Highway km/L  city km/L  Popularity     MSRP  
    11362      Compact         Coupe            14          8         820  2065902  
    11364      Compact         Coupe            14          8         820  1705769  
    8486       Compact         Coupe            14          9        1158  1500000  
    11363      Compact         Coupe            14          8         820  1500000  
    6351         Large   Convertible            16         10          67  1382750  
    6350         Large   Convertible            16         10          67  1380000  
    4024       Compact         Coupe            12          7        2774   643330  
    1622       Midsize   Convertible            16         10        1158   548800  
    1626       Midsize   Convertible            16         10        1158   548800  
    1629       Midsize   Convertible            18         11        1158   535500  
    


```python
import matplotlib.pyplot as plt
import seaborn as sns

plt.figure(figsize=(8, 5))
sns.countplot(x='Transmission Type', data=df, palette="Set2")  # Replace 'Transmission_Type' with the column name in your dataset
plt.title("Frequency of Transmission Types")
plt.xlabel("Transmission Type")
plt.ylabel("Count")
plt.show()

```


    
![png](output_67_0.png)
    



```python
plt.figure(figsize=(15, 5))
sns.countplot(x='Number of Doors', data=df, palette="Set2")  # Replace 'Transmission_Type' with the column name in your dataset
plt.title("Frequency of Number of Doors")
plt.xlabel("Number of Doors")
plt.ylabel("Count")
plt.show()
```


    
![png](output_68_0.png)
    



```python
plt.figure(figsize=(30, 20))
sns.countplot(x='Vehicle Style', data=df, palette="Set3", )  # Replace 'Transmission_Type' with the column name in your dataset
plt.title("Frequency of Vehicle Style", fontsize = 15)
plt.xlabel("TVehicle Style", fontsize = 22)
plt.ylabel("Count" ,fontsize = 25)
plt.show()
```


    
![png](output_69_0.png)
    



```python

avg_msrp_by_brand = df.groupby('Brand')['MSRP'].mean().sort_values()

plt.figure(figsize=(12, 6))
avg_msrp_by_brand.plot(kind='bar', color='skyblue')
plt.title("Average MSRP by Brand")
plt.xlabel("Brand")
plt.ylabel("Average MSRP")
plt.xticks(rotation=45)
plt.show()

```


    
![png](output_70_0.png)
    



```python
# Sample DataFrame (replace this with your actual DataFrame)
data = {
    'Transmission_Type': ['Automatic', 'Manual', 'Automatic', 'Manual', 'Automatic', 'Manual'],
    'MPG': [30, 25, 28, 24, 33, 27]
}

df = pd.DataFrame(data)

# Create the box plot
plt.figure(figsize=(8, 5))
sns.boxplot(x='Transmission_Type', y='MPG', data=df, palette="Set2")
plt.title("MPG Distribution by Transmission Type")
plt.xlabel("Transmission Type")
plt.ylabel("Miles Per Gallon (MPG)")
plt.show()

```


    
![png](output_71_0.png)
    



```python

data = {
    'MSRP': [20000, 25000, 22000, 30000, 27000, 21000, 28000, 26000, 23000, 29000],
    'Horsepower': [150, 200, 180, 250, 230, 170, 240, 210, 160, 220],
    'MPG': [30, 25, 28, 24, 33, 27, 29, 26, 32, 23],
    'Weight': [3000, 3200, 3100, 3500, 3400, 3050, 3300, 3250, 2950, 3150]
}

df = pd.DataFrame(data)


corr = df.corr()


plt.figure(figsize=(10, 6))
sns.heatmap(corr, annot=True, cmap='coolwarm', fmt='.2f', square=True, cbar_kws={"shrink": .8})
plt.title("Heatmap of Correlation Matrix")
plt.show()

```


    
![png](output_72_0.png)
    



```python

```
